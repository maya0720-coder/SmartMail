"""가상 / 실제 데이터 화면 전환과 영업팀 가상 데이터 116통(결정기록 0042)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from app.data_modes import DataModes, build_demo_container, build_modes, demo_settings
from collectors.demo_sales import CUSTOMERS, INTERNAL_DOMAIN, TOTAL_MESSAGES, sales_messages
from domain.clock import FixedClock, OffsetClock
from domain.models import TaskStatus
from fixtures.app_factory import app_client, make_container

NOW = datetime(2026, 11, 17, 6, 0, tzinfo=UTC)  # 15:00 KST


def test_sales_messages_are_116_virtual_mails() -> None:
    messages = sales_messages(NOW)
    assert len(messages) == TOTAL_MESSAGES == 116
    assert len({m.key.message_id for m in messages}) == 116
    for m in messages:
        domain = m.sender_address.rsplit("@", 1)[1]
        # 외부는 예약 도메인(.example), 사내는 example.invalid, 개인 메일은 가짜 아이디만
        assert (
            domain in CUSTOMERS
            or domain == INTERNAL_DOMAIN
            or m.sender_address.startswith("demo-fake-")
        )
        assert NOW - timedelta(days=29) <= m.received_at <= NOW


def test_sales_messages_cover_demo_scenarios() -> None:
    messages = sales_messages(NOW)
    assert any(m.sent_by_me for m in messages)  # 내 회신(완료 후보·회신 대기)
    assert any(m.is_auto for m in messages)  # 뉴스레터(제외 규칙)
    assert any(m.cc_me and not m.to_me for m in messages)  # 참조만
    assert any("[전자결재]" in m.subject for m in messages)


def test_offset_clock_moves_and_resets() -> None:
    clock = OffsetClock()
    past = datetime.now(UTC) - timedelta(days=10)
    clock.at(past)
    assert abs((clock.now() - past).total_seconds()) < 5
    clock.reset()
    assert abs((clock.now() - datetime.now(UTC)).total_seconds()) < 5
    with pytest.raises(ValueError):
        clock.at(datetime(2026, 1, 1))  # 시간대 없는 시각 거부


def test_demo_settings_force_fake_integrations(tmp_path: Path) -> None:
    real = make_container(tmp_path, FixedClock(NOW), demo_mode=False)
    settings = demo_settings(real.settings)
    assert settings.demo_mode and settings.demo_dataset == "sales"
    assert settings.ai_adapter == "fake"
    assert real.settings.demo_mode is False  # 실제 설정은 바뀌지 않음


def test_demo_container_is_isolated_and_seeded(tmp_path: Path) -> None:
    real = make_container(tmp_path, FixedClock(NOW), demo_mode=False)
    demo = build_demo_container(real)
    assert demo.db is not real.db
    assert demo.csrf_token == real.csrf_token
    tasks = demo.tasks.list_tasks()
    assert len(tasks) > 40
    statuses = {t.status for t in tasks}
    assert {TaskStatus.SUGGESTED, TaskStatus.DONE, TaskStatus.IN_PROGRESS} <= statuses
    done = [t for t in tasks if t.status is TaskStatus.DONE]
    assert all(t.closed_at is not None and t.closed_at <= datetime.now(UTC) for t in done)
    assert any(t.gk_registered for t in done)
    assert len(demo.ledger.list_entries()) == len(done)
    assert real.tasks.list_tasks() == []  # 실제 DB에는 아무것도 들어가지 않음
    assert isinstance(demo.clock, OffsetClock)


def test_build_modes_respects_switch_setting(tmp_path: Path) -> None:
    off = make_container(tmp_path, FixedClock(NOW), demo_mode=False, data_mode_switch=False)
    assert build_modes(off).available == ("real",)
    already_demo = make_container(tmp_path / "d", FixedClock(NOW), demo_mode=True)
    assert build_modes(already_demo).available == ("real",)


def test_data_mode_api_switches_container(tmp_path: Path) -> None:
    real = make_container(tmp_path, FixedClock(NOW), demo_mode=False)
    modes = DataModes(real, build_demo_container(real))
    from fastapi.testclient import TestClient

    from app.factory import create_app
    from app.web_security import LOOPBACK_CLIENTS
    from fixtures.app_factory import BASE_URL

    app = create_app(
        real,
        run_background_jobs=False,
        trusted_clients=(*LOOPBACK_CLIENTS, "testclient"),
        modes=modes,
    )
    with TestClient(app, base_url=BASE_URL, raise_server_exceptions=False) as client:
        client.headers.update({"X-CSRF-Token": real.csrf_token})
        assert client.get("/api/data-mode").json() == {
            "current": "real",
            "available": ["real", "demo"],
        }
        assert client.get("/api/tasks").json() == []
        assert client.post("/api/data-mode", json={"mode": "demo"}).json()["current"] == "demo"
        assert len(client.get("/api/tasks").json()) > 40
        page = client.get("/")
        assert "가상 데이터 화면" in page.text and 'data-mode="real"' in page.text
        assert client.post("/api/data-mode", json={"mode": "other"}).status_code == 422
        # CSRF 토큰 없이 전환 불가
        assert (
            client.post(
                "/api/data-mode", json={"mode": "real"}, headers={"X-CSRF-Token": "x"}
            ).status_code
            == 403
        )
        assert client.post("/api/data-mode", json={"mode": "real"}).json()["current"] == "real"
        assert client.get("/api/tasks").json() == []


def test_single_mode_app_has_no_switch(tmp_path: Path) -> None:
    container = make_container(tmp_path, FixedClock(NOW))
    with app_client(container) as client:
        assert client.get("/api/data-mode").json()["available"] == ["real"]
        assert client.post("/api/data-mode", json={"mode": "demo"}).status_code == 409
        assert 'id="data-mode"' not in client.get("/").text
