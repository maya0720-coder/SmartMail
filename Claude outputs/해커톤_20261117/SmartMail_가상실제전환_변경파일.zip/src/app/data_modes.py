"""화면 상단 '가상 / 실제' 데이터 전환(결정기록 0042).

- 실제: 설정 그대로의 컨테이너(실제 메일함·사내 사이트·로컬 DB).
- 가상: 영업팀 가상 메일 116통을 담은 별도 컨테이너(메모리 DB·가짜 연동). 실제 쪽과 DB·세션·
  브라우저를 공유하지 않는다. 앱을 끄면 가상 데이터는 모두 사라진다.
- 전환은 로컬 단일 사용자 앱의 서버 상태 1개로 관리한다(쿠키·브라우저 저장소를 쓰지 않음).
- CSRF 토큰은 보안 미들웨어가 하나만 검사하므로 가상 컨테이너도 실제 컨테이너의 토큰을 쓴다.
"""

from __future__ import annotations

import logging
import threading
from typing import Final, Literal

from app.bootstrap import build_container
from app.container import Container
from app.demo_sales_seed import seed_sales_demo
from config.settings import Settings
from domain.clock import OffsetClock

logger = logging.getLogger(__name__)

DataMode = Literal["real", "demo"]
MODES: Final[tuple[DataMode, ...]] = ("real", "demo")
DEMO_USER_NAME: Final = "김영업"
DEMO_RETENTION_DAYS: Final = 30  # 4주치 가상 이력이 보관기간 작업에 지워지지 않게


class DataModes:
    def __init__(self, real: Container, demo: Container | None, initial: DataMode = "real") -> None:
        self._containers: dict[DataMode, Container] = {"real": real}
        if demo is not None:
            self._containers["demo"] = demo
        self._lock = threading.Lock()
        self._current: DataMode = initial if initial in self._containers else "real"

    @property
    def current(self) -> DataMode:
        return self._current

    @property
    def available(self) -> tuple[DataMode, ...]:
        return tuple(m for m in MODES if m in self._containers)

    def container(self, mode: DataMode | None = None) -> Container:
        return self._containers[mode or self._current]

    def all(self) -> list[Container]:
        return list(self._containers.values())

    def switch(self, mode: DataMode) -> DataMode:
        if mode not in self._containers:
            raise ValueError("사용할 수 없는 데이터 화면입니다")
        with self._lock:
            self._current = mode
        return self._current


def demo_settings(settings: Settings) -> Settings:
    """실제 설정에서 가상(영업팀) 화면용 설정을 만든다. 외부 연동은 모두 가짜로 바뀐다."""
    return settings.model_copy(
        update={
            "demo_mode": True,
            "demo_dataset": "sales",
            "demo_seed": False,
            "ai_adapter": "fake",
            "user_display_name": DEMO_USER_NAME,
            "retention_days": DEMO_RETENTION_DAYS,
            "mail_initial_days": 30,
            "mail_sync_minutes": 0,
            "session_keepalive_minutes": 0,
        }
    )


def build_demo_container(real: Container) -> Container:
    """가상 컨테이너를 만들고 116통 가상 데이터를 채운다."""
    clock = OffsetClock()
    container = build_container(demo_settings(real.settings), clock=clock)
    container.csrf_token = real.csrf_token
    seed_sales_demo(container, clock)
    return container


def build_modes(real: Container) -> DataModes:
    settings = real.settings
    if not settings.data_mode_switch or settings.demo_mode:
        # 전환을 끄거나, 이미 데모 모드로 실행하면 그 화면 하나만 쓴다
        return DataModes(real, None)
    try:
        demo = build_demo_container(real)
    except Exception as exc:
        # 가상 화면 준비가 실패해도 실제 화면은 띄운다(원인은 예외 종류만 기록)
        logger.error("가상 데이터 화면을 만들지 못했습니다: %s", type(exc).__name__)
        demo = None
    return DataModes(real, demo, settings.data_mode_default)
