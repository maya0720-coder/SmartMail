"""가상(영업팀) 화면 전용 가짜 AI(결정기록 0042). 외부 전송 없음.

가짜 AI의 요청 요약에 시연용 요약 제목(`collectors.demo_sales_titles.SUMMARY_TITLES`)을 씌운다.
메일 제목이 표에 없으면 기본 가짜 AI 결과를 그대로 쓴다.
"""

from __future__ import annotations

from dataclasses import replace

from collectors.demo_sales_titles import SUMMARY_TITLES
from domain.ai import RequestDigest
from integrations.ai.fake import _SUBJECT, FakeKnowledgeAI


class SalesDemoAI(FakeKnowledgeAI):
    def _digest(self, text: str) -> RequestDigest | None:
        digest = super()._digest(text)
        match = _SUBJECT.search(text)
        if digest is None or match is None:
            return digest
        subject = match.group(1).strip()
        if len(subject) < 6:
            return digest
        for raw, title in SUMMARY_TITLES.items():
            if raw in subject or subject in raw:
                return replace(digest, title=title[:40])
        return digest
