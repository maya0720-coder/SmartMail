"""가상(영업팀) 화면 전용 가짜 AI(결정기록 0042). 외부 전송 없음.

가짜 AI의 요청 요약에 시연용 요약 제목(`collectors.demo_sales_titles.SUMMARY_TITLES`)을 씌운다.
메일 제목이 표에 없으면 기본 가짜 AI 결과를 그대로 쓴다.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import replace

from collectors.demo_sales_titles import SUMMARY_TITLES
from domain.ai import AiAnswer, RequestDigest
from integrations.ai.fake import _SUBJECT, FakeKnowledgeAI
from security.masking import MaskedText


class SalesDemoAI(FakeKnowledgeAI):
    def _digest(self, text: str) -> RequestDigest | None:
        digest = super()._digest(text)
        match = _SUBJECT.search(text)
        if digest is None or match is None:
            return digest
        subject = match.group(1).strip()
        if len(subject) < 6:
            return digest
        for raw, title in SUMMARY_TITLES.items():
            if raw in subject or subject in raw:
                return replace(digest, title=title[:40])
        return digest

    def suggest_solution(
        self, summary: MaskedText, similar_cases: Sequence[MaskedText]
    ) -> AiAnswer:
        """영업 업무 말투의 가짜 해결 방안(외부 전송 없음)."""
        self.received.append(summary)
        self.received.extend(similar_cases)
        lines = ["요청 유형: 고객·사내 요청(가상 데이터 기준 추정)."]
        if similar_cases:
            lines.append(f"참고 사례 요지: {similar_cases[0].value[:120]}")
        lines += [
            "처리 순서:",
            "1. 고객사·요청 항목(수량·일정·조건)과 회신 기한을 확인",
            "2. 표준 단가표·계약 조건·재고·설치 일정을 담당 부서와 확인",
            "3. 할인·특약이 있으면 전자결재 품의 후 고객에게 회신",
            "조치 방안:",
            "- 회신 후 진행 상태를 '진행 중'으로 바꾸고 기한을 확정",
            "- 반복 문의면 히스토리 카드·G-Knowledge로 남겨 다음 회신 시간을 줄이기",
            f"참고한 사례: {len(similar_cases) or '없음'}건",
        ]
        return AiAnswer(text="\n".join(lines), references=())
