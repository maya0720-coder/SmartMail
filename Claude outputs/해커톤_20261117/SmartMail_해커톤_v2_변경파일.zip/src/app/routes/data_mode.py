"""'가상 / 실제' 데이터 화면 전환 API(결정기록 0042)."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict

from app.data_modes import DataModes

router = APIRouter(prefix="/api/data-mode")


class ModeBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mode: Literal["real", "demo"]


def _modes(request: Request) -> DataModes | None:
    return getattr(request.app.state, "modes", None)


def _state(modes: DataModes | None) -> dict[str, object]:
    if modes is None:
        return {"current": "real", "available": ["real"]}
    return {"current": modes.current, "available": list(modes.available)}


@router.get("")
def current(request: Request) -> JSONResponse:
    return JSONResponse(_state(_modes(request)))


@router.post("")
def switch(request: Request, body: ModeBody) -> JSONResponse:
    modes = _modes(request)
    if modes is None or body.mode not in modes.available:
        return JSONResponse({"error": "사용할 수 없는 데이터 화면입니다."}, status_code=409)
    modes.switch(body.mode)
    return JSONResponse(_state(modes))
