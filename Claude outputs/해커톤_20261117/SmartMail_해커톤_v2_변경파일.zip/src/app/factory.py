"""FastAPI 앱 구성."""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app.container import Container
from app.data_modes import DataModes
from app.errors import register_error_handlers
from app.mail_sync import background_sync
from app.routes import (
    auth,
    categories,
    companies,
    data,
    data_mode,
    followup,
    gk,
    history,
    jobs,
    login_all,
    mail,
    metrics,
    pages,
    summaries,
    task_progress,
    tasks,
    title_rule,
    triage,
    triage_bulk,
    ui_prefs,
    weekly,
    weekly_assist,
    weekly_drafts,
    weekly_links,
    weekly_profiles,
    weekly_share,
)
from app.scheduler import PeriodicJob
from app.summary_job import SUMMARY_INTERVAL_SECONDS
from app.templating import STATIC_DIR
from app.web_security import ALLOWED_HOSTS, LOOPBACK_CLIENTS, SecurityMiddleware
from security.logging_policy import EndReason, EventType, Site, log_event

logger = logging.getLogger(__name__)


SESSION_SWEEP_SECONDS = 60
# 자동 새로고침을 끈 경우(0분)에도 시작 시 1회는 수집한다. 다음 실행은 사실상 없음(1년 뒤)
MAIL_SYNC_ONCE_SECONDS = 366 * 24 * 60 * 60


def _start_jobs(container: Container, run_background_jobs: bool) -> list[PeriodicJob]:
    """컨테이너 1개의 주기 작업을 만들고(필요하면) 시작한다. 반환: 멈출 작업 목록."""
    job = PeriodicJob("retention", container.retention.run)
    sweeper = PeriodicJob("idle", container.sessions.sweep, SESSION_SWEEP_SECONDS)
    # 메일 자동 수집(MAIL-04): 시작 시 1회(처음이면 최근 N일) + 설정 간격마다 증분 수집
    sync_minutes = container.settings.mail_sync_minutes
    mail_job = PeriodicJob(
        "mail-sync",
        lambda: background_sync(container),
        sync_minutes * 60 if sync_minutes > 0 else MAIL_SYNC_ONCE_SECONDS,
    )
    # 업무 제목 AI 요청 요약(결정기록 0014): AI-Ground 로그인 상태에서 2분마다 조금씩
    summary_job = PeriodicJob("summary", container.summary_job.run_once, SUMMARY_INTERVAL_SECONDS)
    # 연결 유지 점검(결정기록 0031): 사이트 쪽 만료 감지. 0분이거나 대상이 없으면 끔
    keepalive_minutes = container.settings.session_keepalive_minutes
    keepalive_job = PeriodicJob(
        "keepalive", container.keepalive.run_once, max(keepalive_minutes, 1) * 60
    )
    keepalive_on = keepalive_minutes > 0 and container.keepalive.enabled
    # 외부 회사명 확인(결정기록 0027): 요약 작업과 같은 주기, 수집 흐름과 분리
    company_job = PeriodicJob("company", container.company_job.run_once, SUMMARY_INTERVAL_SECONDS)
    # G-Knowledge 등록 큐는 사용자가 누른 작업만 처리하므로 항상 켠다(결정기록 0035)
    container.gk_queue.start()
    jobs = [keepalive_job, company_job, summary_job, mail_job, job, sweeper]
    if run_background_jobs:
        job.start()
        sweeper.start()
        mail_job.start()
        summary_job.start()
        company_job.start()
        if keepalive_on:
            keepalive_job.start()
    return jobs


async def _stop_jobs(container: Container, jobs: list[PeriodicJob]) -> None:
    container.gk_queue.stop()
    for periodic in jobs:
        await periodic.stop()
    close = getattr(container.mail.collector, "close", None)
    if callable(close):
        close()
    container.sessions.logout_all(EndReason.APP_STOP)
    container.ai.close()
    container.browser.shutdown()


def create_app(
    container: Container,
    *,
    run_background_jobs: bool = True,
    trusted_clients: tuple[str, ...] = LOOPBACK_CLIENTS,
    modes: DataModes | None = None,
) -> FastAPI:
    data_modes = modes or DataModes(container, None)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        container.residue.run()
        log_event(EventType.APP_START, Site.APP, success=True)
        # 실제·가상 화면의 주기 작업(가상은 가짜 연동만 쓰므로 외부 호출 없음, 결정기록 0042)
        running = [(c, _start_jobs(c, run_background_jobs)) for c in data_modes.all()]
        try:
            yield
        finally:
            for each, jobs in running:
                await _stop_jobs(each, jobs)
            container.residue.run()
            log_event(EventType.APP_STOP, Site.APP, success=True)

    app = FastAPI(
        debug=False,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
        lifespan=lifespan,
    )
    app.state.container = container
    app.state.modes = data_modes
    for each in data_modes.all():
        each.summary_job.auto = run_background_jobs
    register_error_handlers(app, debug=container.settings.debug)
    app.add_middleware(
        SecurityMiddleware,
        csrf_token=container.csrf_token,
        port=container.settings.app_port,
        trusted_clients=trusted_clients,
    )
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=list(ALLOWED_HOSTS))
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
    app.include_router(login_all.router)
    app.include_router(auth.router)
    app.include_router(data.router)
    app.include_router(data_mode.router)
    app.include_router(mail.router)
    app.include_router(categories.router)
    app.include_router(companies.router)
    app.include_router(summaries.router)
    app.include_router(triage.router)
    app.include_router(triage.rules_router)
    app.include_router(triage_bulk.router)
    app.include_router(task_progress.router)
    app.include_router(followup.router)
    app.include_router(tasks.router)
    app.include_router(gk.router)
    app.include_router(jobs.router)
    app.include_router(history.router)
    app.include_router(title_rule.router)
    app.include_router(ui_prefs.router)
    app.include_router(weekly.router)
    app.include_router(weekly_drafts.router)
    app.include_router(weekly_links.router)
    app.include_router(weekly_profiles.router)
    app.include_router(weekly_assist.router)
    app.include_router(weekly_share.router)
    app.include_router(metrics.router)
    app.include_router(pages.router)
    return app
