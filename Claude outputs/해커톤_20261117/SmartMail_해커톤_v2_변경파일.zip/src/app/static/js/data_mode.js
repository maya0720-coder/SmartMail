// 상단 '가상 / 실제' 데이터 화면 전환(결정기록 0042). 서버 상태를 바꾼 뒤 지금 화면을 다시 연다.
"use strict";

(() => {
  const box = document.getElementById("data-mode");
  if (!box) return;
  box.addEventListener("click", async (event) => {
    const button = event.target.closest("button[data-mode]");
    if (!button || button.classList.contains("on")) return;
    for (const b of box.querySelectorAll("button")) b.disabled = true;
    const result = await api("POST", "/api/data-mode", { mode: button.dataset.mode });
    if (!result.ok) {
      for (const b of box.querySelectorAll("button")) b.disabled = false;
      toast(errorText(result, "화면을 바꾸지 못했습니다"), { kind: "error" });
      return;
    }
    // 선택·체크 같은 화면 상태가 다른 데이터에 섞이지 않게 같은 메뉴를 새로 연다
    window.location.assign(window.location.pathname);
  });
})();
