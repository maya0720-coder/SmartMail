"""라우터 공통 의존성."""

from __future__ import annotations

from fastapi import Request

from app.container import Container


def get_container(request: Request) -> Container:
    """지금 선택된 데이터 화면(실제/가상)의 컨테이너(결정기록 0042)."""
    modes = getattr(request.app.state, "modes", None)
    if modes is not None:
        container: Container = modes.container()
        return container
    fallback: Container = request.app.state.container
    return fallback
