"""시연용 '가상' 화면 만들기: 영업팀 가상 메일 116통 수집·요약·처리 이력(결정기록 0042).

- 가상 컨테이너(메모리 DB·가짜 연동)에서만 실행한다. 실제 메일·사이트·로컬 DB를 건드리지 않는다.
- 처리 이력(승인·진행·완료·G-Knowledge 등록·히스토리 카드)은 시각을 과거로 옮겨(OffsetClock)
  기록한다. 그래야 주·월 지표 그래프와 '최근 4주' 흐름이 실제 사용처럼 보인다.
- 결과는 매번 같다(난수 시드 고정). 회사·사람·내용은 모두 가상이다.
"""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Final

from app.container import Container
from collectors.demo_sales import CUSTOMERS
from domain.clock import OffsetClock
from domain.history_service import CardDraft
from domain.models import ResolutionStage, Task, TaskSource, TaskStatus
from domain.tasks.requester import SOURCE_USER
from domain.tasks.service import TaskEdit

logger = logging.getLogger(__name__)

SEED: Final = 116
MAX_SUMMARY_ROUNDS: Final = 40


@dataclass(frozen=True, slots=True)
class SeedResult:
    messages: int
    tasks: int
    done: int
    gk: int
    cards: int


def _card_for(title: str) -> tuple[CardDraft, tuple[str, ...]]:
    """제목 키워드로 영업 업무 히스토리 카드(문제-원인-조치)를 만든다(가상)."""
    rules = [
        (
            ("견적", "단가", "리스"),
            "견적 요청",
            "구성·수량·AS 조건별 단가 산정 필요",
            "표준 단가표 기준 견적 작성 후 할인 품의 상신, 고객 회신",
            ("견적", "B2B"),
        ),
        (
            ("AS", "오류", "인식", "누락", "센서"),
            "장비·소프트웨어 장애",
            "센서 노후·라이선스 동기화 지연",
            "설치기술팀·CS팀 점검 요청, 조치 결과 고객 안내",
            ("AS", "CS"),
        ),
        (
            ("계약", "갱신", "날인"),
            "계약 체결·갱신",
            "특약·손해배상 조항 협의 필요",
            "법무 검토 반영 후 전자결재 품의, 날인본 회수",
            ("계약", "법무"),
        ),
        (
            ("설치", "일정", "교육"),
            "설치·교육 일정 조율",
            "현장 공사·인력 일정 의존",
            "설치기술팀 인력 배정 후 고객 확정, 교육 일정 안내",
            ("설치", "일정"),
        ),
        (
            ("미수", "대금", "세금계산서", "잔금"),
            "대금·채권 관리",
            "고객 지급 일정 미확정",
            "고객 지급일 확인 후 재무팀 회신",
            ("채권", "재무"),
        ),
    ]
    for keys, problem, cause, action, tags in rules:
        if any(k in title for k in keys):
            return CardDraft(f"{problem}: {title}"[:200], cause, action, None), tags
    return (
        CardDraft(
            f"고객·사내 요청: {title}"[:200],
            "요청 사항 확인 필요",
            "담당 부서 협조 후 결과 회신",
            None,
        ),
        ("영업",),
    )


def _summarize_all(container: Container) -> None:
    job = container.summary_job
    for _ in range(MAX_SUMMARY_ROUNDS):
        if not job.pending_ids():
            return
        job.run_once()


def _progress(
    container: Container, clock: OffsetClock, task: Task, rng: random.Random, now: datetime
) -> str:
    """요청 시각과 경과 일수로 처리 상태를 정한다. 반환: 최종 상태 값."""
    assert task.id is not None  # noqa: S101 - 저장된 업무
    requested = task.requested_at or task.created_at
    age = (now - requested).total_seconds() / 86400
    tasks = container.tasks
    if age < 1 or (age < 4 and rng.random() < 0.55):
        return TaskStatus.SUGGESTED.value  # 최근 메일은 아직 제안 목록에 남긴다
    # 기한이 없으면 요청일 + 2~4일로 정한다(지표: 기한 준수율)
    clock.at(requested + timedelta(hours=1))
    due = task.due_at or requested + timedelta(days=rng.choice((2, 3, 4)))
    tasks.approve(task.id, TaskEdit(due_at=due))
    if age < 4:
        if rng.random() < 0.6:
            clock.at(requested + timedelta(hours=3))
            tasks.change_status(task.id, TaskStatus.IN_PROGRESS)
            return TaskStatus.IN_PROGRESS.value
        return TaskStatus.WAITING.value
    roll = rng.random()
    clock.at(requested + timedelta(hours=3))
    if roll < 0.08:
        tasks.change_status(task.id, TaskStatus.ON_HOLD)
        return TaskStatus.ON_HOLD.value
    tasks.change_status(task.id, TaskStatus.IN_PROGRESS)
    if roll < 0.2:
        return TaskStatus.IN_PROGRESS.value
    # 완료: 대부분 기한 안, 일부는 하루 늦게
    late = rng.random() < 0.15
    finish = due + timedelta(hours=10) if late else requested + timedelta(hours=rng.randint(5, 44))
    finish = min(finish, now - timedelta(hours=2))
    clock.at(finish)
    tasks.change_status(task.id, TaskStatus.DONE)
    return TaskStatus.DONE.value


def seed_sales_demo(container: Container, clock: OffsetClock) -> SeedResult:
    """가상 컨테이너에 116통 수집 → 업무 제안 → AI 요약 → 처리 이력을 만든다."""
    rng = random.Random(SEED)  # noqa: S311 - 시연 데이터 배치용(보안 용도 아님)
    for domain, name in CUSTOMERS.items():
        container.company_cache.save(domain, name, SOURCE_USER)
    result = container.mail.sync()
    container.tasks.ingest(result.threads)
    _summarize_all(container)
    # 외부 고객 업무의 요청 부서 칸에 고객사 이름을 넣는다(주간보고 '(요청: …)' 표시용)
    for task in container.tasks.list_tasks():
        company = CUSTOMERS.get(task.requester_domain or "")
        if task.id is not None and company is not None:
            container.tasks.edit(task.id, TaskEdit(requester_dept=company))
    now = clock.now()
    mail_tasks = [
        t
        for t in container.tasks.list_tasks([TaskStatus.SUGGESTED])
        if t.source is TaskSource.MAIL and t.id is not None
    ]
    mail_tasks.sort(key=lambda t: t.requested_at or t.created_at)
    done_ids: list[int] = []
    try:
        for task in mail_tasks:
            if _progress(container, clock, task, rng, now) == TaskStatus.DONE.value:
                assert task.id is not None  # noqa: S101
                done_ids.append(task.id)
        gk = cards = 0
        for task_id in done_ids:
            current = container.tasks.get(task_id)
            closed = current.closed_at or now
            if rng.random() < 0.55:
                clock.at(min(closed + timedelta(hours=2), now - timedelta(minutes=30)))
                draft, tags = _card_for(current.title)
                container.history.save(task_id, draft, tags)
                cards += 1
            if rng.random() < 0.5:
                clock.at(min(closed + timedelta(hours=3), now - timedelta(minutes=20)))
                container.knowledge.register(task_id, container.knowledge.preview(task_id))
                gk += 1
            # 유사 이력 재사용률(MET-04): 완료 업무 일부를
            # 앱·G-Knowledge 이력으로 해결한 것으로 기록
            stage_roll = rng.random()
            if stage_roll < 0.7:
                stage = (
                    ResolutionStage.APP
                    if stage_roll < 0.4
                    else ResolutionStage.GKNOWLEDGE
                    if stage_roll < 0.6
                    else ResolutionStage.AI
                )
                container.ledger.set_resolution(task_id, stage)
    finally:
        clock.reset()
    total = len(container.tasks.list_tasks())
    logger.info("가상 데이터 준비: 메일 %s통, 업무 %s건", result.new_messages, total)
    return SeedResult(result.new_messages, total, len(done_ids), gk, cards)
