"""시연용 영업팀 가상 메일의 공통 정의(결정기록 0042). 회사·사람·주소·내용은 모두 가상이다."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

INTERNAL_DOMAIN: Final = "example.invalid"


ME: Final = "김영업"


TOTAL_MESSAGES: Final = 116


# 외부 고객사 도메인 → 회사명(가상). 시딩 때 회사명 캐시에 '확정'으로 넣는다.
CUSTOMERS: Final[dict[str, str]] = {
    "greenfield-gc.example": "그린필드골프클럽",
    "swingpark.example": "스윙파크 스크린골프",
    "birdiezone.example": "버디존 골프아카데미",
    "pinehills-cc.example": "파인힐스CC",
    "eagle-screen.example": "이글스크린",
    "happyround.example": "해피라운드 골프카페",
    "blueocean-resort.example": "블루오션리조트",
    "wondergolf.example": "원더골프 연습장",
    "skydrive.example": "스카이드라이브 골프센터",
    "mountainview-cc.example": "마운틴뷰CC",
    "haneul-leisure.example": "하늘레저",
    "one-hotel.example": "원호텔앤리조트",
}


@dataclass(frozen=True, slots=True)
class Mail:
    """한 통. days_ago·hour: 기준 시각(지금)으로부터 며칠 전 몇 시(KST)."""

    days_ago: int
    hour: float
    sender: str
    address: str
    subject: str
    body: str
    mine: bool = False
    to_me: bool = True
    cc_me: bool = False
    auto: bool = False
    attachments: tuple[str, ...] = ()


def _sign(name: str, org: str) -> str:
    return f"\n\n감사합니다.\n{name} 드림\n----------------------------------------\n{org}\n"


def _ext(local: str, domain: str) -> str:
    return f"{local}@{domain}"


def _in(local: str) -> str:
    return f"{local}@{INTERNAL_DOMAIN}"


def _reply(days_ago: int, hour: float, subject: str, body: str) -> Mail:
    return Mail(days_ago, hour, ME, _in("sales.kim"), f"RE: {subject}", body, mine=True)
