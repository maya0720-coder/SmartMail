"""시연용 가상 데이터: 골프 시뮬레이터 B2B 영업팀 담당자의 메일 116통.

- 모든 회사·사람·주소·번호·금액은 가상이다. 외부 회사 도메인은 예약 최상위 도메인 `.example`,
  사내 도메인은 `example.invalid`만 쓴다(실제 메일·인물·회사 아님).
- 받는 사람은 가상의 영업팀 담당자 '김영업'이다. 최근 4주에 걸쳐 고객 요청·사내 협조·전자결재·
  공지·뉴스레터·참조 메일·내 회신이 섞여 있어 제안·할 일·지표·주간보고 흐름을 한 번에 보여 준다.
- 이 파일은 데이터만 만든다. 앱 연결(시딩)은 `app/demo_sales_seed.py`가 한다.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from collectors.demo_sales_base import CUSTOMERS, INTERNAL_DOMAIN, ME, TOTAL_MESSAGES, Mail, _in
from collectors.demo_sales_customers import _customer_threads, _short_threads
from collectors.demo_sales_internal import (
    _approval_threads,
    _cc_and_notices,
    _internal_threads,
    _my_questions,
)
from domain.clock import KST
from domain.mail import MailKey, MailMessage
from domain.models import MailSource

__all__ = ["CUSTOMERS", "INTERNAL_DOMAIN", "ME", "TOTAL_MESSAGES", "sales_messages"]


def _all_threads() -> list[list[Mail]]:
    return [
        *_customer_threads(),
        *_short_threads(),
        *_internal_threads(),
        *_approval_threads(),
        *_my_questions(),
        *_cc_and_notices(),
    ]


def _filler(count: int) -> list[list[Mail]]:
    """116통을 맞추기 위한 짧은 후속 회신(받은 감사 인사 등, 업무로 잡히지 않음)."""
    rows = []
    for i in range(count):
        rows.append(
            [
                Mail(
                    27 - (i % 27),
                    18,
                    "영업지원팀 한가상",
                    _in("salesops"),
                    f"영업팀 공지 메일 모음 {i + 1}",
                    "참고용 공유 메일입니다.",
                    to_me=False,
                    cc_me=False,
                    auto=True,
                )
            ]
        )
    return rows


def sales_messages(now: datetime) -> list[MailMessage]:
    """지금(now)을 기준으로 최근 4주 안에 흩어진 가상 메일 116통."""
    threads = _all_threads()
    count = sum(len(t) for t in threads)
    if count < TOTAL_MESSAGES:
        threads += _filler(TOTAL_MESSAGES - count)
    local_now = now.astimezone(KST)
    today = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
    messages: list[MailMessage] = []
    n = 0
    for index, thread in enumerate(threads, start=1):
        thread_id = f"SALES-T{index:03d}"
        for mail in thread:
            n += 1
            when = today - timedelta(days=mail.days_ago) + timedelta(hours=mail.hour)
            if when > local_now:  # 오늘 메일이 아직 오지 않은 시각이면 조금 앞당긴다
                when = local_now - timedelta(minutes=5 * (n % 12 + 1))
            messages.append(
                MailMessage(
                    key=MailKey(
                        MailSource.OUTLOOK,
                        f"SALES-ENTRY-{n:04d}",
                        f"<sales-{n:04d}@{INTERNAL_DOMAIN}>",
                    ),
                    thread_id=thread_id,
                    subject=mail.subject,
                    sender_name=mail.sender,
                    sender_address=mail.address,
                    received_at=when,
                    folder="보낸 편지함" if mail.mine else "받은 편지함",
                    sent_by_me=mail.mine,
                    to_me=mail.to_me and not mail.mine,
                    cc_me=mail.cc_me,
                    is_auto=mail.auto,
                    body=mail.body,
                    attachment_names=mail.attachments,
                )
            )
    return messages[:TOTAL_MESSAGES]
