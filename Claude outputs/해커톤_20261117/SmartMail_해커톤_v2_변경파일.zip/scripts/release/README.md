# 심사·시연용 Windows 배포본 만들기(결정기록 0042)

가상 데이터(영업팀 116통) 전용 실행본을 만든다. 실제 메일·사내 사이트·로컬 DB를 쓰지 않으며, 사내 주소·자격증명을 넣지 않는다.

## 구성

| 파일 | 설명 |
| --- | --- |
| `demo.env` | 배포본 `app\.env`. 데모 모드·영업팀 데이터·포트 18080, 외부 주소는 `*.example.invalid` |
| `SmartMail_실행.bat` / `SmartMail_종료.bat` | 실행(최소화 창 + 브라우저 열기) / 18080 포트 프로세스 종료 |
| `smartmail.nsi` | 설치 파일 스크립트(NSIS, 사용자 권한, `%LOCALAPPDATA%\SmartMail_AX`) |
| `README_심사위원.txt`, `smartmail.ico` | 안내문, 아이콘 |

## 배포본 폴더 구조

```text
SmartMail_AX\
├─ runtime\          # Windows 64비트 Python 3.11(conda-forge) + 운영 의존성(requirements.lock, playwright·pywin32 제외)
├─ app\src\          # 저장소 src 그대로(__pycache__ 제외)
├─ app\.env          # demo.env
├─ app\data\, app\logs\
├─ SmartMail_실행.bat, SmartMail_종료.bat, README_심사위원.txt, smartmail.ico
```

## 만드는 순서(요약)

1. Windows 64비트 Python 3.11 실행 환경을 `runtime\`에 둔다(공식 설치본 또는 conda-forge 패키지).
2. `runtime\python.exe -m pip install --target runtime\Lib\site-packages -r requirements.lock`
   (playwright·pywin32·greenlet·pyee는 데모 모드에서 쓰지 않으므로 빼도 된다).
3. `src`를 `app\src`로 복사하고 `demo.env`를 `app\.env`로 복사한다.
4. `makensis smartmail.nsi`(Linux에서는 `LANG=C.UTF-8` 필요)로 `SmartMail_AX_Setup.exe`를 만든다.

## 주의

- 데모 모드는 메모리 DB만 쓴다. 실행할 때마다 같은 가상 데이터가 '최근 4주' 날짜로 다시 만들어진다.
- 서명되지 않은 설치 파일이라 SmartScreen 경고가 나올 수 있다.
