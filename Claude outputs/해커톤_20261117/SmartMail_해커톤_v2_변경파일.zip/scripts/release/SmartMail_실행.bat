@echo off
setlocal
rem SmartMail (AX CHALLENGE demo) - starts the local server and opens the browser.
cd /d "%~dp0app"
set "PYTHONPATH=%~dp0app\src"
set "PYTHONNOUSERSITE=1"
set "PYTHONUTF8=1"
set "PYTHONHOME="
start "SmartMail" /min "%~dp0runtime\python.exe" -m app.main --open
