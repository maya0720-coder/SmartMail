; SmartMail 심사용 시연판 설치 파일(NSIS). 사용자 권한으로 %LOCALAPPDATA%에 설치한다.
Unicode true
!include "MUI2.nsh"

!define APPNAME "SmartMail 업무 처리 현황"
!define APPDIR  "SmartMail_AX"
Name "${APPNAME} (AX CHALLENGE 시연판)"
OutFile "SmartMail_AX_Setup.exe"
InstallDir "$LOCALAPPDATA\${APPDIR}"
RequestExecutionLevel user
SetCompressor /SOLID lzma
Icon "SmartMail_AX/smartmail.ico"
UninstallIcon "SmartMail_AX/smartmail.ico"

!define MUI_ICON "SmartMail_AX/smartmail.ico"
!define MUI_UNICON "SmartMail_AX/smartmail.ico"
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "지금 SmartMail 실행"
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp
!define MUI_FINISHPAGE_SHOWREADME "$INSTDIR\README_심사위원.txt"
!define MUI_FINISHPAGE_SHOWREADME_TEXT "심사위원 안내 보기"
!define MUI_FINISHPAGE_SHOWREADME_NOTCHECKED
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Korean"

Function LaunchApp
  ExecShell "" "$INSTDIR\SmartMail_실행.bat" "" SW_SHOWMINIMIZED
FunctionEnd

Section "Install"
  ; 이미 실행 중인 시연판이 있으면 먼저 끈다(파일 덮어쓰기 실패 방지)
  IfFileExists "$INSTDIR\SmartMail_종료.bat" 0 +2
    nsExec::Exec '"$INSTDIR\SmartMail_종료.bat"'
  SetOutPath "$INSTDIR"
  File /r "SmartMail_AX/*.*"
  CreateDirectory "$INSTDIR\app\logs"
  CreateDirectory "$INSTDIR\app\data"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateShortCut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\SmartMail_실행.bat" "" "$INSTDIR\smartmail.ico" 0 SW_SHOWMINIMIZED
  CreateDirectory "$SMPROGRAMS\${APPNAME}"
  CreateShortCut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\SmartMail_실행.bat" "" "$INSTDIR\smartmail.ico" 0 SW_SHOWMINIMIZED
  CreateShortCut "$SMPROGRAMS\${APPNAME}\SmartMail 종료.lnk" "$INSTDIR\SmartMail_종료.bat" "" "$INSTDIR\smartmail.ico" 0 SW_SHOWMINIMIZED
  CreateShortCut "$SMPROGRAMS\${APPNAME}\제거.lnk" "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPDIR}" "DisplayName" "${APPNAME} (AX CHALLENGE 시연판)"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPDIR}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPDIR}" "DisplayIcon" "$INSTDIR\smartmail.ico"
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPDIR}" "NoModify" 1
SectionEnd

Section "Uninstall"
  nsExec::Exec '"$INSTDIR\SmartMail_종료.bat"'
  Delete "$DESKTOP\${APPNAME}.lnk"
  RMDir /r "$SMPROGRAMS\${APPNAME}"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPDIR}"
  RMDir /r "$INSTDIR"
SectionEnd
